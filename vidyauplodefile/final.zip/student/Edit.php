<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
    <style>
        table, th, td 
        {
            border:1px solid black;
        }
    </style>
</head>
<body>
    <table>
        <tr>
        <th>U_Name</th>
        <th>Mobile_Number</th>
        <th>Email</th>
        <th>Address</th>
        <th>Password</th>
        <th>Subject</th>
        </tr>

        <tr>
            <!--Data Load-->    <!--Php Code-->
        </tr>
    </table>
    <input type="button" value="Edit" name="Edit">
</body>
</html>